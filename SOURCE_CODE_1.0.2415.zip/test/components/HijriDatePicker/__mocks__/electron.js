module.exports = {
  require: jest.genMockFunction(),
  match: jest.genMockFunction(),
  // app: jest.genMockFunction(),
  remote: jest.genMockFunction(),
  dialog: jest.genMockFunction(),
  app: {
      getPath: (data) => {
        return data;
      }
  },
};
