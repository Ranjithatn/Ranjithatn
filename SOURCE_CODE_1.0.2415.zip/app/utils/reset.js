
export const resetLocalStorage = () => {
	localStorage.removeItem('tenprintListener');

}

