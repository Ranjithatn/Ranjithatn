export default {
	// default path & name: C:\Users\lenovo\AppData\Roaming\Electron\LOGS.json

	// required
	fileName: 'UCW_Logs',

	// the logs will be only stored if enabled is set to true.
	// enabled: true,
}

