import FORM1 from "CardConfigurations/FORM1";

import FORM2 from "CardConfigurations/FORM2";
import FORM2_P2 from "CardConfigurations/FORM2_P2";

import FORM3 from "CardConfigurations/FORM3";
import DemoCard from "CardConfigurations/DemoCard";
import Custom from "CardConfigurations/Custom";

export default {
  FORM1,

  FORM2,
  FORM2_P2,

  FORM3,
  DemoCard,
  Custom,
}
